Config = {}

Config.Coords = {
    {
        coords = vec3(-1321.1029, -184.6503, 49.9713),
        size = vec3(2,2,2),
        rotation = 24.2745
    }
}

Config.NPC = {
	{
		npc = 'a_m_m_soucent_01', 	--https://docs.fivem.net/docs/game-references/ped-models/
		coordinates = vector3(-1321.1029, -184.6503, 48.9713),
		heading = 227.5175,
    }
}