Citizen.CreateThread(function()
	local pedInfo = {}
	local camCoords = nil
	local camRotation = nil

	for k, v in pairs(Config.NPC) do
		RequestModel(GetHashKey(v.npc))
		while not HasModelLoaded(GetHashKey(v.npc)) do
			Wait(1)
		end

		RequestAnimDict("anim@mp_player_intcelebrationfemale@wave")
		while not HasAnimDictLoaded("anim@mp_player_intcelebrationfemale@wave") do
			Wait(1)
		end

		ped = CreatePed(4, v.npc, v.coordinates[1], v.coordinates[2], v.coordinates[3], v.heading, false, true)
		SetEntityHeading(ped, v.heading)
		FreezeEntityPosition(ped, true)
		SetEntityInvincible(ped, true)
		SetBlockingOfNonTemporaryEvents(ped, true)
		TaskPlayAnim(ped,"anim@mp_player_intcelebrationfemale@wave","wave", 8.0, 0.0, -1, 1, 0, 0, 0, 0)

		pedInfo = {
			name = v.name,
			model = v.npc,
			pedCoords = v.coordinates,
			entity = ped,
		}
	end
end)


for i = 1, #Config.Coords do
    local current = Config.Coords[i]

    exports.ox_target:addBoxZone({
        coords = current.coords,
        size = current.size,
        rotation = current.rotation,
        options = {
            {
                icon = 'fa-solid fa-store',
                label = 'Otevřít Menu',
                event = 'bm:otevrit',
            },
        },
        distance = 2
    })
end

  RegisterNetEvent('bm:otevrit')
AddEventHandler('bm:otevrit', function()
    lib.showContext('blackmarket')
end)

lib.registerContext({
    id = 'blackmarket', 
    title = 'Blackmarket', 
    options = {
      {
      title = 'Buy Lockpick',
      description = 'One lockpick = 500Black Money',
      icon = 'check', 
      onSelect = function()
          lib.hideContext() 
          local input = lib.inputDialog('How much do you want to buy ?', {''})
          if not input then return end 
          local count = tonumber(input[1])
          if not count then return end 
          TriggerServerEvent('bm:sell', 'lockpick', count)
      end, 
      arrow = true
      } 
    }, 
  })