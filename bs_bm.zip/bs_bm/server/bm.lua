
local prices = {
    lockpick = 500
}

RegisterNetEvent('bm:sell', function(itemName, count)
    local xPlayer = ESX.GetPlayerFromId(source)
    local item = xPlayer.hasItem(itemName)
    if not item or item.count < count then
        return xPlayer.showNotification("You don't enough of " .. itemName)
    end

    xPlayer.removeInventoryItem('black_money', count * prices[itemName])
    xPlayer.addInventoryItem('lockpick', 1)
    xPlayer.showNotification('You buyed ' .. count .. ' ' .. itemName .. ' from blackmarket for ' .. count * prices[itemName])
end) 